A loose but growing outline what's next steps for OSM Buildings.

# 0.2.0b

- separate rendering layer for flat buildings
- new adapters, i.e. for ArcGIS, Google Maps, Here
- first beta version, keeping API stable
- one or two new roof shapes

# past 0.2.0b

- handle render modes as plugins
- split data handling per layer
- support for new data sources
- roof color by building type
